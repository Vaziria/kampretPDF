<?php
   $header = $single["header"];
   $body = $single["result"];
   $metadata = $single["meta"];
   $sidebar = $single["sidebar"];
   
   $judul =  $kampret->gen("judul");
   
   
?>
<!doctype html>
<html lang="en">
	<head>
        <title><?php echo $judul;?>.</title>
		<meta name="keyword" content="<?PHP echo $metadata['keyword'];?>">
		<meta name="author" content="<?PHP echo $metadata['author'];?>">
		<meta property="og:title" content="<?PHP echo $metadata['title'];?>">
		<meta property="og:url" content="<?PHP echo Url::justWord($judul);?>">

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


        <!-- Main CSS --> 
        <link rel="stylesheet" href="css/style.css">

        <!-- Font Awesome -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>
  
    <body>

        <?php include "header.php"; ?>

        <!-- Main content area -->
        <main class="container">
            <div class="row">
                
                <!-- Main content -->
                <div class="col-md-8">
                    <article>
                        <h2 class="article-title"><?php echo $judul;?>.</h2>

                        <p class="article-meta">Posted on <time><?php echo date("d M");?></time></p>

                        <?php 
						
						$bat = strlen($body['desc']);
						$a = 0;
						while($a<=$bat){
							$c = rand(300,400);
							$d = $a + $c;
							if($d>$bat){
								$c = $bat - $a;
								$c++;
							}
								echo '<p align="justify">'.substr($body['desc'],$a,$c).'</p>';
							$a= $a+$c;
						}
						
						?>
						
						
                    </article>

                   


                    <!-- Example pagination Bootstrap component -->

                </div>

                
               
                
				<?php include "sidebar.php";?> 
                
            </div> 
        </main>


        <!-- Footer -->
        <?php include "footer.php";?> 



        <!-- Bootcamp JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>

    </body>
</html>