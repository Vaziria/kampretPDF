<?php
   $header = $single["header"];
   $body = $single["result"];
   $metadata = $single["meta"];
   $post = $single["post"];
   
   $judul =  $kampret->gen("judul");
   
   
   
   
   //acak
   
   
   //acak deskripsi
   $deskripsi = array();
		$databing = get_bing($kampret->result["title"],1,"title");
		$depanparaf = '<b>'.$kampret->result["title"]." - </b>";
		
		
		$postawal = rand(0,1);
		$dp = "";
		if($postawal!=0){
			$dp = $depanparaf;
			$depanparaf = "";
		}
		
		$a = 0;
		while($a<strlen($kampret->result["desc"])){
			$cc = rand(100,500);
			if($a==0){
				array_push($deskripsi,'<p align="justify">'.$dp.substr($kampret->result["desc"],$a,$cc)."</p>");
			}else{				
				array_push($deskripsi,'<p align="justify">'.substr($kampret->result["desc"],$a,$cc)."</p>");
			}
			$a = $a + $cc;
		}
		
		
		$bingparaf = '<p align="justify">'.$depanparaf.$kampret->keyword_filter(get_bing($kampret->result["title"],1,"title"),"<br>",".")."</p>";
		
		//add acak paragraf bing
		array_splice($deskripsi,$postawal,0,$bingparaf);
		
		
		
		//title bing add to deskripsi
		$bingtitles = explode("<br>",preg_replace("/\<\/strong\>|\<strong\>/","",$databing));
		$bingtitle = "<h3>Related Post</h3><ul>";
		foreach($bingtitles as $dd){
			$bingtitle .= '<li><a href="'.Url::justWord($dd).'">'.$dd.'</a></li>';
		}
		$bingtitle .= "</ul>";
		
		//add bing title di posisi acak
		array_splice($deskripsi,rand(2,count($deskripsi)-1),0,$bingtitle);
		
		
		//add related di posisi acak acak
		$related = "";
		foreach($kampret->result["related"] as $dd){
			$related .= '<li><a href="'.Url::justWord($dd).'">'.$dd.'</a></li>';
		}
		
		$relateds = '<ul>'.$related.'</ul>';	
		array_splice($deskripsi,rand(2,count($deskripsi)-1),0,$relateds);
		
		
		//add top post di posisi acak acak
		$toppost = "";
		foreach($kampret->result["topPost"] as $da){
			$toppost .= '<li><a href="'.Url::justWord($dd).'">'.$da.'</a></li>';
		}
		
		$topposts = '<ul>'.$toppost.'</ul>';	
		array_splice($deskripsi,rand(2,count($deskripsi)-1),0,$topposts);
		
		
		
		
		
		
		$deskripsi = implode("",$deskripsi);
   
   
?>
<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js ie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- Basic Page Needs
   ================================================== -->
   <meta charset="utf-8">
	<title><?php echo $judul;?>.</title>
    <meta name="keyword" content="<?PHP echo $metadata['keyword'];?>">
    <meta name="author" content="<?PHP echo $metadata['author'];?>">
	<meta property="og:title" content="<?PHP echo $metadata['title'];?>">
	<meta property="og:url" content="<?PHP echo Url::justWord($judul);?>">

	<!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

   <!-- CSS
    ================================================== -->
   <link rel="stylesheet" href="css/default.css">
	<link rel="stylesheet" href="css/layout.css">  
	<link rel="stylesheet" href="css/media-queries.css">    

   <!-- Script
   ================================================== -->
	<script src="js/modernizr.js"></script>

   <!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="favicon.png" >

</head>

<body class="single">
<?php include "header.php"; ?>

   <!-- Content
   ================================================== -->
   <div id="content-wrap">

   	<div class="row">

   		<div id="main" class="eight columns">

   			<article class="entry">

					<header class="entry-header">

						<h2 class="entry-title">
							<?php echo $judul;?>.
						</h2> 				 
				
						<div class="entry-meta">
							<ul>
								<li><?php echo date("M, d Y");?></li>
							</ul>
						</div> 
				 
					</header> 
				
					<div class="entry-content-media">
						<div class="post-thumb">
							
						</div> 
					</div>

					<div class="entry-content" align="justify">
						<?php 
						
						echo $deskripsi;
						
						?>
					</div>

					<p class="tags">
  			         <span>Tagged in </span>:
					 <?php
						$a = 0;
						while($a<rand(0,10)){
							$aa = explode(" ",$post[rand(0,count($post)-1)]);
							echo '<a href="#">'.$aa[0].'</a>,';
							
							$a++;
						}
					?>
  				      
  			       </p> 

  			       <ul class="post-nav group">
  			            <li class="prev"><a rel="prev" href="<?php echo Url::justWord($post[0]);?>"><strong>Previous Article</strong> <?php echo $post[0];?></a></li>
  				         <li class="next"><a rel="next" href="<?php echo Url::justWord($post[0]);?>"><strong>Next Article</strong> <?php echo $post[1];?></a></li>
  			        </ul>

				</article>

				<!-- Comments
            ================================================== -->
            <div id="comments">

               


               <!-- respond -->
              

            </div>  <!-- Comments End -->		
   			

   		</div> <!-- main End -->

   		<?php include "sidebar.php"; ?>

  		</div> <!-- end row -->

   </div> <!-- end content-wrap -->   

<?php include "footer.php";?>

</body>

</html>