<?php
require_once "src/model/home.php";
define("sitemap_path","sitemap/");
$kampret = new kampret\keyword("sitemap/");
$post = $kampret->post(false,12);

//data disimpan di variabel homeResult


?>


<!-- Stage- Bootstrap one page Event ticket booking theme 
Created by pixpalette.com - online design magazine -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $post[0]; ?></title>

    <!-- Bootstrap -->
    <link href="src/page/css/bootstrap.min.css" rel="stylesheet">
    <link href="src/page/css/custom.css" rel="stylesheet">
    
    <!-- fonts -->
    <link href='http://fonts.googleapis.com/css?family=Nixie+One' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  	
    <div class="loader">
       <div>
        <img src="src/page/images/icons/preloader.gif" />
       </div>
    </div>
    
    <div class="container-fluid">
		<div class="row">
        	<div class="col-sm-5 left-wrapper">
            	<div class="event-banner-wrapper">
                	<div class="logo">
                        <h1>Great Book Today</h1>
                    </div>
                
                	<h2><a href="<?php echo Url::justWord($post[0]);?>" style="color:white;">
                   <?php echo $post[0];?>
                    <span><?php echo date("d-m-Y");?></span></a>
                    </h2>
                    <p>created by <a href="../home" target="_blank"><?php echo $post[0];?></a></p>
                </div>
            </div>
            <div class="col-sm-7 right-wrapper">
            	<div class="event-ticket-wrapper">
                    
                    <div class="event-tab">
                
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="<?php echo Url::$base;?>" aria-controls="buyTicket" role="tab" data-toggle="tab">Another Books</a></li>
                    <li role="presentation"><a href="<?php echo Url::$base;?>" aria-controls="venue" role="tab" data-toggle="tab">Free Books</a></li>
                   
                    
                    <li role="presentation"><a href="<?php echo Url::$base;?>" aria-controls="termCondition" role="tab" data-toggle="tab">Hot Now</a></li>
                  </ul>
                
                  <!-- Tab panes -->
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="buyTicket">
                    	<div class="row">
							<?php
							$a = 1;
							while($a<count($post)){
								
								echo '<div class="col-md-6">
                            	<div class="ticketBox" data-ticket-price="40000">
                                	<div class="inactiveStatus"></div>
                                    
                                    <div class="row">
 			                       	<div class="col-xs-6">
            							<div class="ticket-name"><a href="'.Url::justWord($post[$a]).'">'.$post[$a].'</a></div>
            						</div>
                                    
                                    <div class="col-xs-6">
            							<div class="ticket-price-count-box">
                                        </div>
            						</div>
                                    </div>
                                	
                                    
                                    <div class="ticket-description">
                                    	<p><strong>'.$post[$a].' - </strong><br>'.substr(get_bing($post[$a],1),0,200).'</p>
                                    </div>
                                            
                                </div>
                            </div>';
								
								$a++;
							}
							
							
							
							?>
                            
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="venue">
                    	<h4> Lorem ipsum dolor sit amet,<br> consectetur adipiscing elit,<br> sed do eiusmod<br> Pune 411058</h4><br>
                        <iframe src="https://www.google.com/maps/d/embed?mid=1UMEBYRnM0KZhrhqikVv3YigwUd0" width="640" height="300"></iframe>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="termCondition">
           				<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</h4>
                        <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</h4>
                        <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</h4>
                    </div>
                  </div>
                
                </div>
                
                	<div class="cart">
                <div class="row">
                    <div class="col-xs-6">
                    </div>
                    <div class="col-xs-6">
                    	<div class="text-right">
                        	<a class="btn disabled" data-toggle="modal" data-target="#ticket-details"></a>
                        </div>
                    </div>
                </div>
                </div>
                       
                </div>
            </div>
        </div>
    </div>

<!-- Modal -->
<div class="modal right fade" id="ticket-details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <!--<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Share your contact Details</h4>
      </div>-->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        	<img src="src/page/images/icons/cancel.png">
        </button>
        <h4 class="modal-title">Your Tickets</h4>
      </div>
      <div class="modal-body">
        
        <div class="cart-information">
            	<div class="ticket-type"></div>
          		<ul>
	                <li>Tickets: <span class="ticket-count"></span></li>
                    <li>Price: <span class="ticket-amount"></span></li>
                    <hr>
                    <li>Total: <span class="total-amount"></span></li>
    			</ul>
            </div>
            
            <div class="contactForm">	
                <h3>Share your contact Details</h3>
                <form>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Enter your name">
                  </div>
                  
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Enter your Email ID">
                  </div>
                  
                  <div class="form-group">
                     <input type="text" class="form-control" placeholder="Enter your Mobile No.">
                  </div>
                  
        		  <a type="submit" class="btn">Proceed to Payment</a>
                </form>
            </div>
        
        
        
      </div>
    </div>
  </div>
</div>
    
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="src/page/js/bootstrap.min.js"></script>
    <script src="src/page/js/allscript.js"></script>
  </body>
</html>