   
   <!-- Header
   ================================================== -->
   <header id="top">

   	<div class="row">

   		<div class="header-content twelve columns">

		      <h1 id="logo-text"><a href="index.php" title=""><?php echo $header[0]; ?>.</a></h1>
				<p id="intro">Great Books Mufles...</p>

			</div>			

	   </div>

	   <nav id="nav-wrap"> 

	   	<a class="mobile-btn" href="#nav-wrap" title="Show navigation">Home</a>
		   <a class="mobile-btn" href="sitemap.xml" title="Hide navigation">Sitemap</a>

	   	<div class="row">    		            

			   	<ul id="nav" class="nav">
			      	<li class="current"><a href="home">Home</a></li>
			      	<li class="has-children"><a href="sitemap.xml">Sitemap</a>
	               </li>

			   	</ul> <!-- end #nav -->			   	 

	   	</div> 

	   </nav> <!-- end #nav-wrap --> 	     

   </header> <!-- Header End -->