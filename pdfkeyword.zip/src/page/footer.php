<div class="container footer-container">
            <footer class="footer">
                <div class="footer-lists">
                    <div class="row">
                        <div class="col-sm">
                            <ul>
                                
                            </ul>
                        </div>
                        <div class="col-sm">
                            <ul>
                                
                            </ul>
                        </div>   
                        <div class="col-sm">
                            <ul>
                               
                            </ul>
                        </div>
                        <div class="col-sm">
                            <h4></h4>
                            <p></p>

                            <p class="social-icons">
                                <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                                <a href="#"><i class="fa fa-twitter fa-2x"></i></a>
                                <a href="#"><i class="fa fa-youtube fa-2x"></i></a>
                                <a href="#"><i class="fa fa-instagram fa-2x"></i></a>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="footer-bottom">
                        <p class="text-center">Web Template by <a href="https://zypopwebtemplates.com/">ZyPop</a>.</p>
                        <p class="text-center"><a href="#">Back to top</a></p>
                </div>
            </footer>
        </div>