<?php

$keyword = new kampret\keyword($__config);

$keyword->g_add("minyak wangi bandung");

print_r($keyword->g_keywords);

?>